import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Sara {

    public static int minMovimientos(int[]dp, int total){
        
        int mov=0;
        
        int prom=total/dp.length;
        if(prom==0){
            prom=1;
        }
        for (int i=0; i<dp.length;i++){
            int need=prom;
            int j=1;
            while(dp[i]<prom && i+j<dp.length){
                    
                    if(dp[i+j]>=prom){
                        dp[i]+=need;
                        dp[j+i]-=need;
                        mov+=need*j;
                        need-=prom;
                    }
                    
                    else{
                        dp[i]+=dp[i+j];
                        mov+=dp[i+j]*j;
                        need-=dp[i+j];
                        dp[j+i]=0;  
                    }
                    
                    if(dp[i]<dp[i+1] && i-j>1 && dp[i-j-1]-dp[i-j]-dp[i]>=need && need>0){
                        dp[i]+=need;
                        dp[i-j]-=need;
                        mov+=need*j;
                        need=0;
                    }
                    prom=(total-dp[i])/dp.length;       
                    j++;
            }
        }
        int x=0;
        while(dp[dp.length-1]>dp[dp.length-2]){
            if(dp[x]==dp[x+1]){
                dp[x]+=1;
                mov+=dp.length-x-1;}

            else{
                dp[x+1]+=1;
                mov+=dp.length-x-2;}

            x++;
            dp[dp.length-1]-=1;

            if(x==dp.length){
                x=0;
            }
        }
        return mov;
    }

    public static void main(String[] args) throws Exception {
        FileWriter fw = new FileWriter("P1.Out");
        try (FileReader fr = new FileReader("./P1.in")) {
            BufferedReader br = new BufferedReader(fr);
            String pruebas= br.readLine();
            for(int i = 0 ;  i<Integer.parseInt(pruebas); i++){
                String torres = br.readLine();
                List<String> listaDeCadenas = Arrays.asList(torres.split(" "));
                int [] torre=new int[Integer.parseInt(listaDeCadenas.get(0))];
                int total=0;
                
                for(int j =1; j <Integer.parseInt(listaDeCadenas.get(0))+1; j++){
                    
                    torre[j-1]=Integer.parseInt(listaDeCadenas.get(j));
                if (j>0){
                    total+=Integer.parseInt(listaDeCadenas.get(j));  
                   
                }
            } 

                System.out.println(minMovimientos(torre,total));
                
            }  
            fw.close();
         }
         catch(Exception e){
            e.printStackTrace();
         }

    }
}
